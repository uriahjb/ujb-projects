function puma_viz()
    p = puma260;
end